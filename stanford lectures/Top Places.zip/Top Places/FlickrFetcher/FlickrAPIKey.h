//
//  FlickrAPIKey.h
//
//  Created for Stanford CS193p Fall 2011.
//  Copyright 2011 Stanford University. All rights reserved.
//
//  Get your own key!
//  No Flickr fetches will work without the API Key!
//

#define FlickrAPIKey @"2d57c18bb70d5b3aea7b3b0034567af1"
