//
//  RecentlyViewedViewController.h
//  Top Places
//
//  Created by David Barton on 18/04/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PhotoListViewController.h"

@interface RecentPhotoListViewController : PhotoListViewController

@end
