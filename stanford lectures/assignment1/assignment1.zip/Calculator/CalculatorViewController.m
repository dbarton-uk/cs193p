    //
    //  CalculatorViewController.m
    //  Calculator
    //
    //  Created by David Barton on 27/02/2012.
    //  Copyright (c) 2012. All rights reserved.
    //

#import "CalculatorViewController.h"
#import "CalculatorBrain.h"

@interface CalculatorViewController ()

@property (nonatomic) BOOL userIsInTheMiddleOfEnteringNumber;
@property (nonatomic, strong) CalculatorBrain *brain;

@end

@implementation CalculatorViewController

@synthesize display;
@synthesize calculation;
@synthesize userIsInTheMiddleOfEnteringNumber;
@synthesize brain = _brain;

- (CalculatorBrain *)brain {
    if (!_brain) _brain = [[CalculatorBrain alloc] init];
    return _brain;
}

- (void)appendToCalculation:(NSString*) text {
	
	self.calculation.text = 
		[self.calculation.text stringByReplacingOccurrencesOfString:@"= " 
														 withString:@""];
	self.calculation.text = 
		[self.calculation.text stringByAppendingString:
			[NSString stringWithFormat:@"%@ ", text]];
}

- (IBAction)digitPressed:(UIButton *)sender {
    NSString *digit = [sender currentTitle];
    
    if (self.userIsInTheMiddleOfEnteringNumber) {
        self.display.text = [self.display.text stringByAppendingString:digit]; 
    } else {
        self.display.text = digit;
        self.userIsInTheMiddleOfEnteringNumber = YES;
    }    
}

- (IBAction)operationPressed:(UIButton *)sender {
	if (self.userIsInTheMiddleOfEnteringNumber) {
        [self enterPressed];
    }	
	NSString *operation = [sender currentTitle];
	[self appendToCalculation: [operation stringByAppendingString:@" ="]];	
	double result = [self.brain performOperation:operation];
    self.display.text = [NSString stringWithFormat:@"%g", result];
		//  [self performOperation:[sender currentTitle]];
}

- (IBAction)enterPressed {
    [self.brain pushOperand:[self.display.text doubleValue]];
	[self appendToCalculation:self.display.text];	
    self.userIsInTheMiddleOfEnteringNumber = NO;
}

- (IBAction)pointPressed {  
	
	NSRange range = [self.display.text rangeOfString:@"."]; 		
	if (range.location == NSNotFound) {
		self.display.text = [self.display.text stringByAppendingString:@"."];
	}        
	self.userIsInTheMiddleOfEnteringNumber = YES;    
}

- (IBAction)clearPressed {
    [self.brain empty];
    self.display.text = @"0";
    self.calculation.text = @"";
	self.userIsInTheMiddleOfEnteringNumber = NO;
}

- (IBAction)backspacePressed {
	self.display.text =[self.display.text substringToIndex:
						[self.display.text length] - 1]; 
	
	if ( [self.display.text isEqualToString:@""]
		|| [self.display.text isEqualToString:@"-"]) {

		self.display.text = @"0";
		self.userIsInTheMiddleOfEnteringNumber = NO;
	}
}

- (IBAction)signChangePressed:(UIButton *)sender {
    
    if (self.userIsInTheMiddleOfEnteringNumber) {        
        if ([[self.display.text substringToIndex:1] isEqualToString:@"-"]) {            
            self.display.text = [self.display.text substringFromIndex:1];
        } else {
            self.display.text = [@"-" stringByAppendingString:self.display.text]; 
        }
    } else {
		[self operationPressed:sender];
    }    
}

- (void)viewDidUnload {
    [super viewDidUnload];
}



@end
