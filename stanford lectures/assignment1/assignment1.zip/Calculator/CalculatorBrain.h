//
//  CalculatorBrain.h
//  Calculator
//
//  Created by David Barton on 27/02/2012.
//  Copyright (c) 2012. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CalculatorBrain : NSObject

- (void)pushOperand:(double)operand;
- (double)performOperation:(NSString *)operation;
- (void)empty;

@end
