//
//  CalculatorAppDelegate.h
//  Calculator
//
//  Created by David Barton on 27/02/2012.
//  Copyright (c) 2012. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CalculatorAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
